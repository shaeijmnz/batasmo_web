import { useEffect, useState } from 'react';
import './HomePage.css';
import './ClientTheme.css';
import {
  fetchClientHomeData,
  calendarDaysFromTodayLocal,
  subscribeToClientAppointments,
} from '../lib/userApi';
import { attachLiveDataRefresh } from '../lib/liveDataRefresh';
import { initialChatbotMessages, sendChatbotMessage } from '../lib/chatbotService';

const ScalesIcon = ({ size = 24, color = '#f5a623' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="3" x2="12" y2="21" />
    <path d="M5 21h14" />
    <path d="M3 6l9-3 9 3" />
    <path d="M3 6l3 9H0L3 6z" />
    <path d="M21 6l3 9h-6l3-9z" />
  </svg>
);

const MenuIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" />
  </svg>
);

const BellIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);

const CalendarIcon = ({ size = 28, color = '#f5a623' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const DocumentIcon = ({ size = 28, color = '#f5a623' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
  </svg>
);

const ClockIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
  </svg>
);

const AIIcon = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2a4 4 0 0 1 4 4v1h1a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3v-6a3 3 0 0 1 3-3h1V6a4 4 0 0 1 4-4z" />
    <circle cx="9" cy="13" r="1" fill="#fff" stroke="none" />
    <circle cx="15" cy="13" r="1" fill="#fff" stroke="none" />
    <path d="M9 17s1 1 3 1 3-1 3-1" />
  </svg>
);

const MessageIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </svg>
);

const DashboardIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
  </svg>
);
const MyApptIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="15" x2="16" y2="15"/>
  </svg>
);
const NotarialIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/>
  </svg>
);
const AnnouncementIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
  </svg>
);
const TransactionIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
  </svg>
);
const LogsIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/>
  </svg>
);
const ProfileIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
  </svg>
);

function HomePage({ onNavigate, profile, onSignOut }) {
  const [chatOpen, setChatOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activePage, setActivePage] = useState('Dashboard');
  const [chatMsg, setChatMsg] = useState('');
  const [appointments, setAppointments] = useState([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [loadError, setLoadError] = useState('');
  const [messages, setMessages] = useState(initialChatbotMessages);
  const [chatLoading, setChatLoading] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    let isMounted = true;

    const loadData = async () => {
      if (!profile?.id) return;

      try {
        const { appointments: appts, notifications: notif } = await fetchClientHomeData(profile.id);
        if (isMounted) {
          setAppointments(appts);
          setNotifications(notif);
        }
      } catch (error) {
        if (isMounted) {
          setLoadError(error.message || 'Failed to load dashboard data.');
        }
      }
    };

    const detachLiveRefresh = attachLiveDataRefresh({
      enabled: Boolean(profile?.id),
      reload: () => {
        void loadData();
      },
      subscribe: (onRealtime) => subscribeToClientAppointments(profile.id, onRealtime),
      pollMs: 12000,
    });

    return () => {
      isMounted = false;
      detachLiveRefresh();
    };
  }, [profile?.id]);

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const markAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const getNotifIcon = (type) => {
    switch (type) {
      case 'booking':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1e3a8a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
        );
      case 'approved':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
          </svg>
        );
      case 'payment':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
            <text
              x="12"
              y="17"
              textAnchor="middle"
              fill="#f5a623"
              fontSize="15"
              fontWeight="700"
              fontFamily="system-ui, -apple-system, 'Segoe UI', sans-serif"
            >
              ₱
            </text>
          </svg>
        );
      case 'reminder':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
          </svg>
        );
      case 'consultation':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#b45309" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="8" y1="13" x2="16" y2="13" />
            <line x1="8" y1="17" x2="14" y2="17" />
          </svg>
        );
      case 'rejected':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>
          </svg>
        );
      case 'admin_announcement':
      case 'admin_message':
      case 'admin_notice':
      case 'notarial_update':
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1e3a8a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        );
      default:
        return (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4b5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
        );
    }
  };

  const getNotifColor = (type) => {
    switch (type) {
      case 'booking': return '#eff6ff';
      case 'approved': return '#ecfdf5';
      case 'payment': return '#fffbeb';
      case 'consultation': return '#fff7ed';
      case 'reminder': return '#eef2ff';
      case 'rejected': return '#fef2f2';
      case 'admin_announcement':
      case 'admin_message':
      case 'admin_notice':
      case 'notarial_update':
        return '#eff6ff';
      default: return '#f3f4f6';
    }
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    const question = chatMsg.trim();
    if (!question || chatLoading) return;

    setMessages(prev => [
      ...prev,
      { from: 'user', text: question }
    ]);
    setChatMsg('');

    setChatLoading(true);
    try {
      const response = await sendChatbotMessage({
        message: question,
        profile,
        conversation: messages,
      });

      setMessages(prev => [
        ...prev,
        {
          from: 'ai',
          text: response.reply,
          actions: Array.isArray(response.actions) ? response.actions : [],
        },
      ]);
    } catch (error) {
      setMessages(prev => [
        ...prev,
        {
          from: 'ai',
          text: 'I hit an issue while processing your message. Please try again.',
          actions: [{ label: 'Open booking', page: 'book-appointment' }],
        },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="hp-page">

      {/* Sidebar overlay */}
      {sidebarOpen && <div className="hp-sidebar-overlay" onClick={() => setSidebarOpen(false)} />}

      {/* Sidebar */}
      <aside className={`hp-sidebar ${!sidebarOpen ? 'hp-sidebar--closed' : ''}`}>
        <div className="hp-sidebar__header">
          <button className="hp-sidebar__toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
            <MenuIcon />
          </button>
          <div className="hp-sidebar__logo">
            <img src="/logo/logo.jpg" alt="Logo" className="hp-sidebar__logo-img" />
            <ScalesIcon size={26} color="#f5a623" />
            <span>BatasMo</span>
          </div>
        </div>
        <nav className="hp-sidebar__nav">
          {[
            { label: 'Dashboard',           icon: <DashboardIcon /> },
            { label: 'Book Appointment',    icon: <CalendarIcon size={18} color="#9ca3af" /> },
            { label: 'My Appointments',     icon: <MyApptIcon /> },
            { label: 'Notarial Requests',   icon: <NotarialIcon /> },
            { label: 'Announcements',       icon: <AnnouncementIcon /> },
            { label: 'Transaction History', icon: <TransactionIcon /> },
            { label: 'Logs',                icon: <LogsIcon /> },
            { label: 'Profile',             icon: <ProfileIcon /> },
          ].map(item => (
            <button
              key={item.label}
              className={`hp-sidebar__item ${activePage === item.label ? 'hp-sidebar__item--active' : ''}`}
              onClick={() => { setActivePage(item.label); setSidebarOpen(false); if (item.label === 'Profile') onNavigate('profile'); if (item.label === 'Book Appointment') onNavigate('book-appointment'); if (item.label === 'My Appointments') onNavigate('my-appointments'); if (item.label === 'Notarial Requests') onNavigate('my-notarial-requests'); if (item.label === 'Announcements') onNavigate('announcements'); if (item.label === 'Transaction History') onNavigate('transaction-history'); if (item.label === 'Logs') onNavigate('client-logs'); }}
            >
              <span className="hp-sidebar__item-icon">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Content */}
      <main className="hp-main">
        {/* Welcome */}
        <div className="hp-welcome">
          <div className="hp-welcome__content">
            <h1>Welcome Back, {profile?.full_name || 'Client'}</h1>
            <p>Here's what's happening with your legal matters today.</p>
          </div>
          <img src="/lady-justice/lady justice.jpg" alt="Lady Justice" className="hp-welcome__image" />
        </div>
        {loadError ? <p>{loadError}</p> : null}

        {/* Action Cards */}
        <div className="hp-actions">
          <div className="hp-action-card" onClick={() => onNavigate('book-appointment')}>
            <div className="hp-action-card__icon">
              <CalendarIcon />
            </div>
            <div>
              <h3>Book New Appointment</h3>
              <p>Schedule a consultation with our expert attorneys</p>
            </div>
          </div>
          <div className="hp-action-card" onClick={() => onNavigate('notarial-request')}>
            <div className="hp-action-card__icon">
              <DocumentIcon />
            </div>
            <div>
              <h3>Request Notary</h3>
              <p>Notary requests are completed on the BatasMo mobile app</p>
            </div>
          </div>
        </div>

        {/* Consultation Queue */}
        <div className="hp-queue-card">
          <div className="hp-queue-card__header">
            <h2>Consultation Queue</h2>
            <button className="hp-view-all" onClick={() => onNavigate('my-appointments')}>View All</button>
          </div>
          <p className="hp-queue-subtitle">Your upcoming consultations sorted by date</p>
          <div className="hp-queue-list">
            {[...appointments]
              .sort((a, b) => new Date(a.date) - new Date(b.date))
              .map((a, i) => {
                const today = new Date();
                const apptDate = new Date(a.date);
                const todayCal = new Date(today.getFullYear(), today.getMonth(), today.getDate());
                const apptCal = new Date(apptDate.getFullYear(), apptDate.getMonth(), apptDate.getDate());
                const isToday = todayCal.getTime() === apptCal.getTime();
                const isPast = apptCal < todayCal;
                const daysUntil = calendarDaysFromTodayLocal(a.date);
                
                const formatDate = (dateStr) => {
                  const d = new Date(dateStr);
                  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
                };

                return (
                  <div key={i} className={`hp-queue-item ${isToday ? 'hp-queue-item--today' : ''} ${isPast ? 'hp-queue-item--past' : ''}`}>
                    <div className="hp-queue-item__position">
                      <span className="hp-queue-number">{i + 1}</span>
                    </div>
                    <div className="hp-queue-item__date-block">
                      <span className="hp-queue-month">{new Date(a.date).toLocaleDateString('en-US', { month: 'short' })}</span>
                      <span className="hp-queue-day">{new Date(a.date).getDate()}</span>
                    </div>
                    <div className="hp-queue-item__info">
                      <span className="hp-queue-item__name">{a.name}</span>
                      <span className="hp-queue-item__area">{a.area}</span>
                      <span className="hp-queue-item__time">
                        <ClockIcon /> {formatDate(a.date)} at {new Date(a.time).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
                      </span>
                    </div>
                    <div className="hp-queue-item__right">
                      <div className="hp-queue-item__badges">
                        <span className={`hp-badge hp-badge--status hp-badge--${String(a.status).toLowerCase()}`}>{a.status}</span>
                        <span className={`hp-badge hp-badge--pay hp-badge--${a.payment.toLowerCase()}`}>{a.payment}</span>
                      </div>
                      {a.payment === 'Paid' && a.chatAccessible ? (
                        <div className="hp-queue-item__today-actions">
                          {isToday ? <span className="hp-today-label">TODAY</span> : null}
                          <button className="hp-enter-room-btn" onClick={() => onNavigate('chat-room', { appointmentId: a.id })}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                            </svg>
                            Enter Room
                          </button>
                        </div>
                      ) : a.payment === 'Paid' && !a.chatAccessible && isToday ? (
                        <div className="hp-queue-item__today-actions">
                          <span className="hp-today-label">TODAY</span>
                          <span className="hp-payment-needed">Available at scheduled time</span>
                        </div>
                      ) : isToday && a.payment !== 'Paid' ? (
                        <div className="hp-queue-item__today-actions">
                          <span className="hp-today-label">TODAY</span>
                          <span className="hp-payment-needed">Pay first to enter</span>
                        </div>
                      ) : isPast ? (
                        <span className="hp-queue-item__status-text hp-queue-item__status-text--past">Completed</span>
                      ) : (
                        <span className="hp-queue-item__status-text">
                          {daysUntil === 1 ? 'Tomorrow' : daysUntil > 1 ? `In ${daysUntil} days` : 'Past'}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </main>

      {/* AI Chatbot FAB */}
      <button className="hp-chat-fab" onClick={() => setChatOpen(!chatOpen)} title="AI Assistant">
        <AIIcon />
      </button>

      {/* Chat Window */}
      {chatOpen && (
        <div className="hp-chat-window">
          <div className="hp-chat-window__header">
            <div className="hp-chat-window__title">
              <AIIcon />
              <span>BatasMo AI</span>
            </div>
            <button className="hp-chat-window__close" onClick={() => setChatOpen(false)}>✕</button>
          </div>
          <div className="hp-chat-window__messages">
            {messages.map((m, i) => (
              <div key={i} className={`hp-msg hp-msg--${m.from}`}>
                <p>{m.text}</p>
                {m.from === 'ai' && Array.isArray(m.actions) && m.actions.length > 0 ? (
                  <div className="hp-msg__actions">
                    {m.actions.map((action, actionIndex) => (
                      <button
                        key={`${action.label}-${actionIndex}`}
                        type="button"
                        className="hp-msg__action-btn"
                        onClick={() => onNavigate(action.page, action.params || {})}
                      >
                        {action.label}
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            ))}
            {chatLoading ? (
              <div className="hp-msg hp-msg--ai hp-msg--typing">
                <p>Typing...</p>
              </div>
            ) : null}
          </div>
          <form className="hp-chat-window__input" onSubmit={sendMessage}>
            <input
              type="text"
              placeholder="Ask me anything..."
              value={chatMsg}
              onChange={e => setChatMsg(e.target.value)}
              disabled={chatLoading}
            />
            <button type="submit" disabled={chatLoading || !chatMsg.trim()}>Send</button>
          </form>
        </div>
      )}
    </div>
  );
}

export default HomePage;
